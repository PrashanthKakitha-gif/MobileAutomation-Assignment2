package pageObjects;

import TestFunctions.BaseTest;

public class UdemyLoginPageObjects extends BaseTest{
	
	//android.widget.Button[@text="Open side drawer"]
	//android.widget.TextView[@text="Log in"]
	//android.widget.CheckBox[@text="Verify you are human"]
	
}
