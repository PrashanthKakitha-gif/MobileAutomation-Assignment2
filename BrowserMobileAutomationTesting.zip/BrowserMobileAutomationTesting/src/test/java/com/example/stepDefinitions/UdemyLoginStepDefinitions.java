package com.example.stepDefinitions;

import io.appium.java_client.AppiumDriver;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.qameta.allure.*;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;
import pageObjects.UdemyLoginPageObjects;
import utils.listeners.AllureTestListener;

@Listeners({AllureTestListener.class})

public class UdemyLoginStepDefinitions extends UdemyLoginPageObjects {
	private AppiumDriver driver;


	public UdemyLoginStepDefinitions(){
		System.out.println("Initializing LoginSteps...");
		this.driver = Hooks.getDriver();
		if (driver == null) {
			System.out.println("Driver is null in LoginSteps constructor!");
			throw new RuntimeException("Driver is not initialized.");
		}
	}
	@Given("User lanches the udemy mobile homepage")
	@Test(priority = 1, description = "Launch The URL")
	@Epic("Adactin Application")
	@Feature("Launch The Adactin URL")
	@Story("Story Name: To check the URL Launch")
	@Severity(SeverityLevel.CRITICAL)
	@Description("Test Case Description: Verify User Able to Launch the URL")
	@Owner("Viveka")
	@Link(name = "Website", url = "https://adactinhotelapp.com/HotelAppBuild2/index.php")
	@Issue("Auth-123")
	@TmsLink("TMS-456")
	@AllureId("Authentication")
	public void user_lanches_the_udemy_mobile_homepage() {
		String CurrentMethod = new Throwable().getStackTrace()[0].getMethodName();
		System.out.println(CurrentMethod);
	    //setup();
//	    driver.get("https://www.udemy.com/");
	}
	@Given("User navigated to loginpage")
	public void user_navigated_to_loginpage() {
		
	}
	@When("user enters the email id {string} and password {string}")
	public void user_enters_the_email_id_and_password(String string, String string2) {
	    
	}
	@Then("User views the invalid login errors")
	public void user_views_the_invalid_login_errors() {
	    
	}

}
