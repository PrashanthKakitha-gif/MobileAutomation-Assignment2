package ResuableMethods;

public class JavaUtility {

}
